import mysql.connector
import requests
import json
import os
from datetime import datetime

# ==========================================
# CONFIGURACIÓN
# ==========================================
DB_CONFIG = {
    'host': 'localhost',
    'user': 'ADOPCION_APP',
    'password': 'AppAdopciones4455!',
    'database': 'ADOPCION_APP' # Ajusta al nombre de tu BD
}

BREVO_API_KEY = os.environ.get('BREVO_API_KEY', 'xsmtpsib-aaec1cff0829a581b0aa9e7adca53836f14e055494dc51e95401af3c323321f8-6mC6TyalJoyRpcZA')
BREVO_SENDER_EMAIL = 'javalgonz@gmail.com'
BREVO_SENDER_NAME = 'Sistema Bienestar Animal'

# ==========================================
# CONEXIÓN A BD
# ==========================================
def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# ==========================================
# LÓGICA PRINCIPAL
# ==========================================
def process_matches():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # 1. Obtener las personas que tienen coincidencias sin notificar
    # (Equivalente al primer FOR p IN (...) de Oracle)
    query_persons = """
        SELECT DISTINCT p.id AS person_id, ce.email, CONCAT(p.firstName, ' ', p.firstLastName) AS person_name
        FROM PetMatch pm
        JOIN Pet pet_l ON pm.idLostPet = pet_l.id
        JOIN Pet pet_f ON pm.idFoundPet = pet_f.id
        JOIN Person p ON p.id IN (pet_l.idPerson, pet_f.idPerson)
        JOIN ContactEmail ce ON ce.idPerson = p.id
        WHERE pm.notified = 0 AND ce.email IS NOT NULL AND TRIM(ce.email) != ''
    """
    cursor.execute(query_persons)
    persons = cursor.fetchall()

    for person in persons:
        person_id = person['person_id']
        email = person['email']

        # 2. Obtener las mascotas asociadas a esta persona (Equivalente al segundo FOR m IN (...))
        query_matches = """
            SELECT pl.name AS lost_name, pf.name AS found_name, pm.matchScore,
                (SELECT photoURL FROM Photo ph WHERE ph.idPet = pf.id LIMIT 1) AS found_photo
            FROM PetMatch pm
            JOIN Pet pl ON pm.idLostPet = pl.id
            JOIN Pet pf ON pm.idFoundPet = pf.id
            WHERE (pl.idPerson = %s OR pf.idPerson = %s)
              AND pm.notified = 0
        """
        cursor.execute(query_matches, (person_id, person_id))
        matches = cursor.fetchall()

        if not matches:
            continue

        # 3. Construir el HTML (Idéntico al de Oracle)
        html_body = "<h2>Coincidencias de Mascotas Encontradas</h2><ul>"
        
        for m in matches:
            lost_name = m['lost_name'] if m['lost_name'] else 'Sin nombre'
            found_name = m['found_name'] if m['found_name'] else 'Sin nombre'
            photo_url = m['found_photo'] if m['found_photo'] else 'https://via.placeholder.com/120?text=Sin+Foto'

            html_body += f"""
            <li style="margin-bottom: 15px; list-style: none;">
                <table style="border-collapse: collapse;">
                    <tr>
                        <td style="padding-right: 15px; vertical-align: top;">
                            <img src="{photo_url}" alt="Foto Mascota" style="width: 120px; height: 120px; object-fit: cover; border-radius: 8px; border: 1px solid #ccc;" />
                        </td>
                        <td style="vertical-align: top;">
                            <p style="margin: 0 0 5px 0;"><b>Mascota Perdida:</b> {lost_name}</p>
                            <p style="margin: 0 0 5px 0;"><b>Encontrada:</b> {found_name}</p>
                            <p style="margin: 0; color: #27ae60;"><b>Coincidencia:</b> {m['matchScore']}%</p>
                        </td>
                    </tr>
                </table>
            </li><br>
            """
        
        html_body += "</ul>"

        # 4. Enviar el correo vía API de Brevo
        if send_email_brevo(email, "Coincidencia detectada de mascota", html_body):
            print(f"Correo enviado a {email}")
        else:
            print(f"Error enviando a {email}")

    # 5. Marcar como notificados solo los que acabamos de procesar
    # Usamos el email de las personas procesadas para actualizar sus matches correspondientes
    if persons:
        # Para evitar problemas, actualizamos en bloque todos los que sean notified=0
        # (Igual que hacías en tu Oracle con el UPDATE final)
        cursor.execute("UPDATE PetMatch SET notified = 1 WHERE notified = 0")
        conn.commit()
        print("Base de datos actualizada: notified = 1")

    cursor.close()
    conn.close()

# ==========================================
# FUNCIÓN PARA ENVIAR VÍA BREVO
# ==========================================
def send_email_brevo(to_email, subject, html_content):
    url = "https://api.brevo.com/v3/smtp/email"
    headers = {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json"
    }
    payload = {
        "sender": {
            "name": BREVO_SENDER_NAME,
            "email": BREVO_SENDER_EMAIL
        },
        "to": [
            {
                "email": to_email
            }
        ],
        "subject": subject,
        "htmlContent": html_content
    }

    response = requests.post(url, headers=headers, data=json.dumps(payload))
    
    if response.status_code == 201:
        return True
    else:
        print(f"Error Brevo ({response.status_code}): {response.text}")
        return False

if __name__ == "__main__":
    process_matches()